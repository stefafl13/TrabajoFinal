import pymysql

def get_connection():
    return pymysql.connect('localhost','root','rootroot','Backend')

