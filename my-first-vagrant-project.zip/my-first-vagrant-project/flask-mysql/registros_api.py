from flask import Flask, request, jsonify
from bson.json_util import dumps
from bson.objectid import ObjectId
from flask_cors import CORS
import pymysql
import db
import dbm

app = Flask(__name__)
CORS(app)

@app.route("/paciente/<codigo>", methods=['GET'])
def get_cargo(codigo):
    con = db.get_connection() 
    cursor = con.cursor(pymysql.cursors.DictCursor)
    retorno={}
    try:
        sql="SELECT * FROM Paciente WHERE cedula = '{}'".format(codigo)
        cursor.execute(sql)
        retorno = cursor.fetchone()
        return jsonify(retorno)
    finally:
        con.close()
        print("Conexion cerrada")

@app.route("/login/<usuario>", methods=['GET'])
def get_paciente(usuario):
    con = db.get_connection() 
    cursor = con.cursor(pymysql.cursors.DictCursor)
    retorno={}
    try:
        sql="SELECT contrasena FROM Personal_medico WHERE usuario = '{}'".format(usuario)
        cursor.execute(sql)
        retorno = cursor.fetchone()
        return jsonify(retorno)
    finally:
        con.close()
        print("Conexion cerrada")

@app.route("/paciente", methods=['GET'])
def get_pacientes():
    con = db.get_connection()
    cursor = con.cursor(pymysql.cursors.DictCursor)
    try:
        sql="SELECT * FROM Paciente"
        cursor.execute(sql)
        retorno = cursor.fetchall()
        return jsonify(retorno)
    finally:
        con.close()
        print("Conexion cerrada")

@app.route("/novedad", methods=['GET'])
def get_novedades():
    con = dbm.get_connection()
    dbnov = con.dbnovedades
    try:
        novedades = dbnov.novedad
        response = app.response_class(
            response=dumps(novedades.find()),
            status=200,
            mimetype='application/json'
        )
        return response
    finally:
        con.close()
        print("Connection closed")

@app.route("/novedad/<code>", methods=['GET'])
def get_novedad(code):
    con = dbm.get_connection()
    dbnov = con.dbnovedades
    try:
        novedades = dbnov.novedad
        response = app.response_class(
            response=dumps(novedades.find({'cedula': code})),
            status=200,
            mimetype='application/json'
        )
        return response
    finally:
        con.close()
        print("Connection closed")

@app.route("/novedad/<code>", methods=['DELETE'])
def delete_novedad(code):
    con = dbm.get_connection()
    dbnov = con.dbnovedades
    try:
        novedades = dbnov.novedad
        novedades.delete_one({'_id': ObjectId(code)})
        return jsonify({"message":"OK"})
    finally:
        con.close()
        print("Connection closed")

@app.route("/novedad", methods=['POST'])
def create_novedad():
    data = request.get_json()
    con = dbm.get_connection()
    dbnov = con.dbnovedades  
    try:
        novedades = dbnov.novedad
        novedades.insert(data)
        return jsonify({"message":"OK"})
    finally:
        con.close()
        print("Connection closed")


@app.route("/paciente/<codigo>", methods=['PUT'])
def update(codigo):
    data = request.get_json()
    nombre = data['nombre']
    con = db.get_connection()
    cursor = con.cursor()
    try:
        sql="UPDATE Paciente set Nombres='{0}' WHERE cedula = '{1}'".format(nombre, codigo)
        cursor.execute(sql)
        con.commit()
        return jsonify({"mensaje":"OK"})
    finally:
        con.close()
        print("Conexion cerrada")

@app.route("/paciente/<codigo>", methods=['DELETE'])
def delete(codigo):
    con = db.get_connection()
    cursor = con.cursor()
    try:
        sql="DELETE FROM Paciente_Medico WHERE Paciente_cedula = '{}'".format(codigo)
        cursor.execute(sql)
        con.commit()
        sql="DELETE FROM Paciente WHERE cedula = '{}'".format(codigo)
        cursor.execute(sql)
        con.commit()
        return jsonify({"mensaje":"OK"})
    finally:
        con.close()
        print("Conexion cerrada")

