import React, { useEffect, useState, useCallback } from 'react';
import InfoCarousel from '../InfoCarousel/InfoCarousel';
import Card from 'react-bootstrap/Card';
import { useAppContext } from '../lib/contextLib';
import Col from 'react-bootstrap/Col';
import Row from 'react-bootstrap/Row';
import Button from 'react-bootstrap/Button';
import Modal from 'react-bootstrap/Modal';
import Form from 'react-bootstrap/Form';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faEdit, faTrashAlt } from '@fortawesome/free-solid-svg-icons';

function Home() {

    const { isAuthenticated } = useAppContext();
    const fetchPacientes = useCallback(async () => {
        try {
          const response = await fetch(`http://localhost:5000/paciente`);
          const pacientesJson = await response.json();
          setPaciente(pacientesJson);
        } catch (e) {
          console.error(e);
        }
      }, []);
    
      const [pacientes, setPaciente] = useState(null);
      useEffect(() => {
        fetchPacientes();
      }, [fetchPacientes]);

    /*const [pacientes, setPaciente] = useState(null);
    useEffect(() => {
        fetch(`json/pacientes.json`)
            .then(res => res.json())
            .then(setPaciente)
            .catch(console.error);
    }, []);*/

    const [show, setShow] = useState(false);
    //const handleClose = () => setShow(false);
    const handleShow = (cedula2) => {
        setShow(true);
        setCedula(cedula2);
        setMedico(isAuthenticated.Usuario);
        
    }
    /*const handleShow = useCallback(async (cedula) => {
        alert(cedula);
        setShow(true);
        setCedula(cedula);
    },[]);*/

    const [fecha, setFecha] = useState('');
    const [temperatura, setTemperatura] = useState('');
    const [presion, setPresion] = useState('');
    const [nivelGlucosa, setNivelGlucosa] = useState('');
    const [spO2, setSpO2] = useState('');
    const [sintomas, setSintomas] = useState('');
    const [tratamiento, setTratamiento] = useState('');
    const [novedades, setNovedades] = useState('');
    const [cedula, setCedula] = useState('');
    const [medico, setMedico] = useState('');

    function validateForm() {
        return fecha.length > 0 && 
            temperatura.length > 0 && 
            presion.length>0 && 
            nivelGlucosa.length>0 &&
            spO2.length>0 &&
            sintomas.length>0 &&
            tratamiento.length>0 &&
            novedades.length>0;
    }

    const handleClose = () => {
        setShow(false);
        setFecha('');
        setTemperatura('');
        setPresion('');
        setNivelGlucosa('');
        setSpO2('');
        setSintomas('');
        setTratamiento('');
        setNovedades('');
    }

    const handleSave = useCallback(async () => {
        try {
          const response = await fetch(`http://localhost:5000/novedad`, {
            method: 'post',
            headers: {'Content-Type':'application/json'},
            body: JSON.stringify({
              fecha,
              temperatura,
              presion,
              nivelGlucosa,
              spO2,
              sintomas,
              tratamiento,
              novedades,
              cedula,
              medico
            })
           });
          const responseJson = await response.json();
          alert("Novedad creada");
          handleClose();
        } catch (e) {
          console.error(e);
        }
      }, [fecha, temperatura, presion, nivelGlucosa, spO2, sintomas, tratamiento, novedades]
    );

    const handleDelete = useCallback(async (cedula) => {
        try {
          const response = await fetch(`http://localhost:5000/paciente/${cedula}`, {method: 'delete'});
          const responseJson = await response.json();
          alert("Paciente eliminado");
          fetchPacientes();
        } catch (e) {
          console.error(e);
        }
      }, [fetchPacientes]
    );

    if (pacientes) {
        return (
            <>
                <InfoCarousel></InfoCarousel>
                <Card>
                    <Card.Body>
                        <h1>Seguimientos</h1>
                        {isAuthenticated ? (
                            <>
                                <section>
                                    <Row lg={1}>
                                        {pacientes.map(paciente => (
                                            <Col lg={4}>
                                                <Card className="movie-card">
                                                    <ul className="actions">
                                                        <li><Button variant="primary" onClick={() => handleDelete(paciente.cedula)}><FontAwesomeIcon icon={faTrashAlt} /></Button></li>
                                                    </ul>
                                                    <Card.Body>
                                                        <Card.Title>{paciente.Apellidos}</Card.Title>
                                                        <Card.Subtitle className="mb-2 text-muted">{paciente.Nombres}</Card.Subtitle>
                                                        <Card.Text>
                                                            Categoría: {paciente.cedula}<br />
                                                            Enfermedad: {paciente.Tipo_de_Sangre}
                                                        </Card.Text>
                                                        <Button className="mb-2" variant="primary" href={`/info/${paciente.cedula}`} value={paciente.cedula}>Ver información del paciente</Button>{' '}
                                                        <Button className="mb-2" variant="outline-primary" onClick={() => handleShow(paciente.cedula)}>Agregar novedad</Button>{' '}
                                                    </Card.Body>
                                                </Card>
                                            </Col>
                                        ))}
                                    </Row>

                                </section>

                                <Modal show={show} onHide={handleClose}>
                                    <Modal.Header closeButton>
                                        <Modal.Title>Novedad</Modal.Title>
                                    </Modal.Header>
                                    <Modal.Body>
                                            <Form>
                                                <Form.Group>
                                                    <Form.Label>Fecha</Form.Label>
                                                    <Form.Control className="form-control" type="datetime-local" values={fecha} onChange={(e)=>setFecha(e.target.value)} />
                                                </Form.Group>
                                                <Form.Group>
                                                    <Form.Label>Temperatura</Form.Label>
                                                    <Form.Control className="form-control" type="number" values={temperatura} onChange={(e)=>setTemperatura(e.target.value)} />
                                                </Form.Group>
                                                <Form.Group>
                                                    <Form.Label>Presión</Form.Label>
                                                    <Form.Control type="text" values={presion} onChange={(e)=>setPresion(e.target.value)} />
                                                </Form.Group>
                                                <Form.Group>
                                                    <Form.Label>Nivel de glucosa</Form.Label>
                                                    <Form.Control className="form-control" type="number" values={nivelGlucosa} onChange={(e)=>setNivelGlucosa(e.target.value)} />
                                                </Form.Group>
                                                <Form.Group>
                                                    <Form.Label>Saturación de oxígeno</Form.Label>
                                                    <Form.Control className="form-control" type="number" values={spO2} onChange={(e)=>setSpO2(e.target.value)} />
                                                </Form.Group>
                                                <Form.Group>
                                                    <Form.Label>Sintomas</Form.Label>
                                                    <Form.Control type="text" values={sintomas} onChange={(e)=>setSintomas(e.target.value)} />
                                                </Form.Group>
                                                <Form.Group>
                                                    <Form.Label>Tratamiento</Form.Label>
                                                    <Form.Control type="text" values={tratamiento} onChange={(e)=>setTratamiento(e.target.value)} />
                                                </Form.Group>
                                                <Form.Group>
                                                    <Form.Label>Novedades</Form.Label>
                                                    <Form.Control type="text" values={novedades} onChange={(e)=>setNovedades(e.target.value)} />
                                                </Form.Group>
                                            </Form>
                                    </Modal.Body>
                                    <Modal.Footer>
                                        <Button variant="secondary" onClick={handleClose}>
                                            Cerrar
                                        </Button>
                                        <Button variant="primary" onClick={handleSave} disabled={!validateForm()}>
                                            Guardar Novedad
                                        </Button>
                                    </Modal.Footer>
                                </Modal>
                            </>
                        ) : (
                                <>
                                    <p>Por favor, inicie sesión para ver los pacientes que tiene bajo su cuidado. En caso de que aun no se haya registrado, comuníquese con nosotros para crear una cuenta y pueda realizar sus registros.</p>
                                    <Button className="mr-2" href="/login" >Iniciar sesión</Button>
                                    <Button href="/contact">Contáctenos</Button>
                                </>
                            )
                        }
                    </Card.Body>
                </Card>
            </>
        );
    }
    return null;

}

export default Home;