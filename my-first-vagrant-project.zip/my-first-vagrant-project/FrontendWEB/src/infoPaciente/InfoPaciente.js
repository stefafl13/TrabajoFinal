import React from 'react';
import './InfoPaciente.css';
import { useEffect, useState, useCallback } from 'react';
import Card from 'react-bootstrap/Card';
import Button from 'react-bootstrap/Button';
//import { useAppContext } from '../lib/contextLib';
import Container from 'react-bootstrap/Container';
import Modal from 'react-bootstrap/Modal';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faTrashAlt } from '@fortawesome/free-solid-svg-icons';
import { useHistory } from 'react-router-dom';

function InfoPaciente(props) {
    const isAuthenticated = true;

    const fetchPacientes = useCallback(async () => {
        try {
          //const response = await fetch(`../json/${props.match.params.id}.json`);
          const response = await fetch(`http://localhost:5000/paciente/${props.match.params.id}`);
          const pacientesJson = await response.json();
          setPaciente(pacientesJson);
        } catch (e) {
          console.error(e);
        }
      }, []);


    const [pacientes, setPaciente] = useState([]);
    
    useEffect(() => {
    fetchPacientes();
    }, [fetchPacientes]);


    const [show, setShow] = useState(false);
    const history = useHistory();
    const handleClose = () => {
        setShow(false);
        fetchPacientes();
        alert(novs);
      }

    const handleShow = useCallback(async(var1) => {
        if(var1){
            try{
                const response = await fetch(`http://localhost:5000/novedad/${var1}`);
                const novedadesJson = await response.json();
                //setNovedad(novedadesJson);
                
                if(novedadesJson.length==0){
                    alert('No hay novedades');
                    setShow(false);
                }else{
                    setNovedad(novedadesJson);
                    setShow(true);
                }
                
            }catch (e) {
                console.error(e);
            }
        }
    },[]); 

    const [novs, setNovedad] = useState([]);

    const handleDelete = useCallback(async (movie,var1) => {
        history.push('/home')
        setShow(false);
        try {
          const response = await fetch(`http://localhost:5000/novedad/${movie}`, {method: 'delete'});
          const responseJson = await response.json();
          alert("Novedad eliminada");
          
        } catch (e) {
          console.error(e);
        }
      }, []
    );
      
    /*const fetchNovedades = useCallback(async () => {
    try {
        //const response = await fetch(`../json/${props.match.params.id}.json`);
        const response = await fetch(`http://localhost:5000/novedad/123`);
        const novedadesJson = await response.json();
        setNovedad(novedadesJson);
        console.log(novedades);
    } catch (e) {
        console.error(e);
    }
    }, []);
    
    
    useEffect(() => {
    fetchNovedades();
    }, [fetchNovedades]);*/

    if (pacientes) {
        return (
            <>
            <Container>
                <section>
                    <Card className="card-all">
                        <Card.Body>
                            <Card.Title>{pacientes.Nombres} {pacientes.Apellidos}</Card.Title>
                            <Card.Subtitle className="mb-2 text-muted">Categoría: {pacientes.Nombres}</Card.Subtitle>
                            <Card.Text>
                                Teléfono: {pacientes.telefono}<br/>
                                Dirección: {pacientes.direccion}<br/>
                                EPS: {pacientes.EPS}<br/>
                                Tipo de sangre: {pacientes.Tipo_de_sangre}<br/>
                                Categoría: {pacientes.Nombres}<br/>
                                Alergias: {pacientes.Alergias}<br/>
                                Enfermedades: {pacientes.Enfermedades}<br/>
                                Medicamentos: {pacientes.Medicamentos}<br/>
                            </Card.Text>
                        </Card.Body>
                        {isAuthenticated && <Button variant="primary" onClick={() => handleShow(pacientes.cedula)}>Ver novedades</Button>}
                    </Card>
                </section>
                <section show={show}>
                    {novs.map(nov =>(
                        <Card className="movie-card">
                            <ul className="actions">
                                <li><Button variant="primary" onClick={() => handleDelete(nov._id.$oid,pacientes.cedula)}><FontAwesomeIcon icon={faTrashAlt} /></Button></li>
                            </ul>
                            <Card.Body>
                                <Card.Title>Medico: {nov.medico}</Card.Title>
                                <Card.Subtitle className="mb-2 text-muted">Fecha: {nov.fecha}</Card.Subtitle>
                                <Card.Text>
                                    Temperatura: {nov.temperatura} <br/>
                                    Presion: {nov.presion} <br/>
                                    Nivel de glucosa: {nov.nivelGlucosa} <br/>
                                    SpO2: {nov.spO2} <br/>
                                    Sintomas: {nov.sintomas} <br/>
                                    Tratamiento: {nov.tratamiento} <br/>
                                    Novedades: {nov.novedades} <br/>
                                </Card.Text>
                            </Card.Body>
                        </Card>
                    ))}
                </section>

            </Container>
                {/*<Modal show={show} onHide={handleClose}>
                    <Modal.Header closeButton>
                        <Modal.Title>{novs}</Modal.Title>
                    </Modal.Header>
                    
                    <Modal.Footer>
                        <Button variant="secondary" onClick={handleClose}>
                            Cerrar
                        </Button>
                        <Button variant="primary" onClick={handleClose}>
                            Guardar
                        </Button>
                    </Modal.Footer>
                </Modal>*/}
            </>
        );
    }
    return null;
}

export default InfoPaciente;