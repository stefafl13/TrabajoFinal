import React, { useState, useEffect, useCallback } from 'react';
import './MovieSearcher.css';
import Container from 'react-bootstrap/Container';
import Form from 'react-bootstrap/Form';
import Button from 'react-bootstrap/Button';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import Card from 'react-bootstrap/Card';
import Modal from 'react-bootstrap/Modal';
import { Link } from 'react-router-dom';
import { useAppContext } from '../lib/contextLib';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faEdit, faTrashAlt } from '@fortawesome/free-solid-svg-icons';

function InfoPaciente(props) {

  const { isAuthenticated } = useAppContext();

  const fetchMovies = useCallback(async () => {
    try {
      const response = await fetch(`https://f43bf2e8c1e7.ngrok.io/movies`);
      const moviesJson = await response.json();
      setMovies(moviesJson);
    } catch (e) {
      console.error(e);
    }
  }, []);

  const [movies, setMovies] = useState([]);
  useEffect(() => {
    fetchMovies();
  }, [fetchMovies]);

  const [show, setShow] = useState(false);

  const handleClose = () => {
    setShow(false);
    setMovieId(undefined);
    setTitle('');
    setSynopsis('');
    setImage('');
  }
  const handleShow = useCallback(async (movie) => {
    if (movie) {
      try {
        const response = await fetch(`https://f43bf2e8c1e7.ngrok.io/movies/${movie}`);
        const movieJson = await response.json();
        setMovieId(movieJson._id.$oid);
        setTitle(movieJson.title);
        setSynopsis(movieJson.synopsis);
        setImage(movieJson.image);
      } catch (e) {
        console.error(e);
      }
    }
    setShow(true);
  }, []);

  const [movieId, setMovieId] = useState(undefined);
  const [title, setTitle] = useState('');
  const [synopsis, setSynopsis] = useState('');
  const [image, setImage] = useState('');

  const handleSave = useCallback(async () => {
      try {
        const response = await fetch(`https://f43bf2e8c1e7.ngrok.io/movies`, {
          method: 'post',
          headers: {'Content-Type':'application/json'},
          body: JSON.stringify({
            title,
            synopsis,
            image
          })
         });
        const responseJson = await response.json();
        alert("pelicula creada");
        fetchMovies();
        handleClose();
      } catch (e) {
        console.error(e);
      }
    }, [image, synopsis, title, fetchMovies]
  );

  const handleEdit = useCallback(async (movie) => {
    try {
      const response = await fetch(`https://f43bf2e8c1e7.ngrok.io/movies/${movieId}`, {
        method: 'put',
        headers: {'Content-Type':'application/json'},
        body: JSON.stringify({
          title,
          synopsis,
          image
        })
       });
      const responseJson = await response.json();
      alert("pelicula actualizada");
      fetchMovies();
      handleClose();
    } catch (e) {
      console.error(e);
    }
  }, [movieId, image, synopsis, title, fetchMovies]
);

  const handleDelete = useCallback(async (movie) => {
    try {
      const response = await fetch(`https://f43bf2e8c1e7.ngrok.io/movies/${movie}`, {method: 'delete'});
      const responseJson = await response.json();
      alert("pelicula eliminada");
      fetchMovies();
    } catch (e) {
      console.error(e);
    }
  }, [fetchMovies]
);

  if (movies) {
    return (
      <>
      <Container>
        <Form inline className="mb-5">
          <Form.Label htmlFor="nombrePelicula" srOnly>
            Nombre pelicula
          </Form.Label>
          <Form.Control className="mr-2" id="nombrePelicula" placeholder="Nombre de pelicula" />
          <Button type="submit">
            Buscar
          </Button>
        </Form>
  
        <section>
          { isAuthenticated && <Button className="mb-3" variant="primary" onClick={() => handleShow()}>Crear pelicula</Button> }
          <Row>
            {movies.map(movie => (
              <Col lg={4} key={movie._id.$oid}>
                <Card className="movie-card" style={{ width: '18rem', margin: '0 auto 1rem' }}>
                  { isAuthenticated &&
                  <ul className="actions">
                    <li><Button variant="primary" onClick={() => handleShow(movie._id.$oid)}><FontAwesomeIcon icon={faEdit} /></Button></li>
                    <li><Button variant="primary" onClick={() => handleDelete(movie._id.$oid)}><FontAwesomeIcon icon={faTrashAlt} /></Button></li>
                  </ul>
                  }
                  <Card.Img variant="top" src={movie.image} />
                  <Card.Body>
                    <Card.Title>{movie.title}</Card.Title>
                    <Card.Text>
                      {movie.synopsis}
                    </Card.Text>
                    <Link to={`/movie/${movie._id.$oid}`}>Ver más</Link>
                  </Card.Body>
                </Card>
              </Col>
            ))}
          </Row>
        </section>
      </Container>

      <Modal show={show} onHide={handleClose}>
        <Modal.Header closeButton>
          <Modal.Title>Crear pelicula</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Form>
            <Form.Group>
              <Form.Label>Título</Form.Label>
              <Form.Control type="text" value={title} onChange={(e) => setTitle(e.target.value)} />
            </Form.Group>
            <Form.Group>
              <Form.Label>Sinopsis</Form.Label>
              <Form.Control type="text" value={synopsis} onChange={(e) => setSynopsis(e.target.value)} />
            </Form.Group>
            <Form.Group>
              <Form.Label>Imagen</Form.Label>
              <Form.Control type="text" value={image} onChange={(e) => setImage(e.target.value)} />
            </Form.Group>
          </Form>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={handleClose}>
            Cerrar
          </Button>
          <Button variant="primary" onClick={movieId ? handleEdit : handleSave}>
            Guardar
          </Button>
        </Modal.Footer>
      </Modal>
      </>
    );
  }
  return null;
}

export default MovieSearcher;